
Lab 4: Enhance microservice (deployed @ PCF) by pulling some data
-----------------------------------------------------------------

In this Lab we will access a data service hosted in PCF platform. This will help use to understand concepts like service marketplace, 
provisioning a new service, binding the service to an app


+ For creating a dataservice, let's lookup the services available in the marketplace:

```
cf marketplace
```

+ Create a database service 'greeting-data' as below:

```
cf create-service SERVICE PLAN SERVICE_INSTANCE
```

+ Next objective is to create a table in database, populate with some data and and access the database from an app (web service).



+ Bind the dataservice to our application:

```
cf bind-service greeting greeting-data
cf restage greeting
```
