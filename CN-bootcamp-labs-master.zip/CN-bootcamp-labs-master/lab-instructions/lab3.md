Lab 3: Access a microservice from another microservice
--------------------------------------------------------

In this Lab we will access one microservice from another service using Spring REST Template. This will help us to understand without direct method call, one service accesses
another service through Web URL.

+ Checkout the repository from github:

```
git clone http://topgear-training-gitlab.wipro.com/SA388263/CN-bootcamp-labs.git
git checkout tags/lab3-start -b lab3

```

+ Try compiling the repository

```
mvn clean compile
```

+ Our existing REST Controller - GreetingController - accepts web request from user & responds with a "hello" greeting!

Class GreetingController - notice the request mapping

```
package hello;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

	private static final String template = "Hello, %s!";
	private final AtomicLong counter = new AtomicLong();

	@RequestMapping("/greeting")
	public Greeting greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
		System.out.println("hello...");
		return new Greeting(counter.incrementAndGet(), String.format(template, name));
	} 

```

+ We need to create a new REST Controller - say BootcampController - representing another Microservice that can accept web request from user at a different URL (say, /route)
& routes the request to our earlier service (HelloController) and shows the response to the user (in browser). The response will be the greeting message received earlier.


+ Create a new REST Controller BootcampController with RequestMapping /route and use Spring REST Template to access the URL of earlier service.


```
package bootcamp;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
...

@RestController
public class BootcampController 
{

.....
		
	@RequestMapping("/route")
	public Greeting route() {
		System.out.println("BootcampController: Enter route");
		.....
		//Use REST Template to access the other service URL

		return greeting;        
	}


}
```

+ Does your code compile and you can run the services. While server boots up, does the new mapping show up. What changes you have done in the application to
have Requestmapping of two different controllers in two different packages from the same Application.

+ Can you re-deploy the application on PCF platform by changing the route information in code (In enterprise deployment, you might like to configure the route 
information externally, but here try out by changing the target URL inside your code).



