Lab 2: Deploy microservice in Pivotal Cloud Foundry
----------------------------------------------------

In this lab, we will take the codebase that you have from Lab 1 and deploy it in Pivotal Cloud Foundry.

- Build the app war file.

```
mvn clean package -DskipTests -Dmaven.test.skip=true
```

+ Create a developer account with Pivotal Cloud Foundry & log in to the Developer console

```
use URL: https://login.run.pivotal.io/login
```

+ Know Your Credentials and Target

Before you can push your app to Cloud Foundry you need to know:
  - The API endpoint for your Cloud Foundry instance. Also known as the target URL, this is api.run.pivotal.io.
  - Your username and password for your Cloud Foundry instance.
  - The organization and space where you want to deploy your app. A Cloud Foundry workspace is organized into organizations, and within them, spaces. 
	As a Cloud Foundry user, you have access to one or more organizations and spaces. For out Bootcamp, we will use the domain sandbox (the default and only domain
	available under a registered developer account).

+ Before pushing your app to Cloud Foundry, have a look at the steps involved in deploying of application to CloudFoundry 

![Image of deployment](CN-app-deployment-steps.png)

+ push your app to Cloud Foundry

```
cf push greeting -p target/greeting.war --random-route
```

Do you see any error?
Have you noticed the buildbacks pulled out during deployment?

![Image of deployment](PCF-buildpacks.png)


+ Notice the route above and try accessing the application URL through browser

Please refer to the following screenshots of deployment


```
http://<application-route>/greeting
```

+ Is your other service also working?

```
http://<application-route>/newgreeting
```

List down the issues you have faced in deploying the application in PCF.

