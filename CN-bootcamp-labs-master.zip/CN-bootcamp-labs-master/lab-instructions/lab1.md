Lab 1 - Build a microservice & run locally
------------------------------------------

+ Checkout the repository from github:

```
git clone http://topgear-training-gitlab.wipro.com/SA388263/CN-bootcamp-labs.git
git checkout tags/lab1-start -b lab1

```

+ Try compiling the repository

```
mvn clean compile
```

Do you see any compilation error?
Fix the issue and recompile. Code should be compiled before moving to the next step.


+ Run the compiled code as a Springboot application

```
mvn spring-boot:run
```
![Image of deployment](deploy_local_01.png)
![Image of deployment](deploy_local_02.png)


+ Access application URL through browser

```
http://localhost:8080/greeting
```
![Image of deployment](deploy_local_browser.png)

+ Now go to class GreetingController. Notice the RequestMapping annotation. Try adding a new method in this controller class with a new request mapping URL.
For example, the new URL mapping can be like the following:

```
http://localhost:8080/newgreeting
```

