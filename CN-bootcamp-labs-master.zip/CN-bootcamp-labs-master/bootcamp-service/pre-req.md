Pre-requisites: 
------------------------------

JDK  Installation
-------------------
Install JDK 1.8 from http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
Setup JAVA_HOME and include JAVA_HOME/bin in path.



Maven  Installation
-------------------
Download Maven from here (https://maven.apache.org/download.cgi).
Unzip Maven binaries, set MAVEN_HOME and keep MAVEN_HOME in path. 



Git  Installation
-------------------

- The official build is available for download on the Git website. For a readily available version for windows, go to http://git-scm.com/download/win and the download will start automatically. 
- Note that this is a project called Git for Windows, which is separate from Git itself; for more information on it, go to https://git-for-windows.github.io/.



Git Command reference:
--------------------------
In case you are not familiar with using Git, you can browse through this page (https://www.tutorialspoint.com/git/index.htm) and other similar resources to familirialize with how typicall you access a remote git
repository and make changes in code and update the repository.
Fot our Bootcamp a minimal knowledge of accessing Git, checking out a repository branch is needed.


Cloud Foundry CLI Installation
------------------------------

- Download the Windows installer (https://cli.run.pivotal.io/stable?release=windows64)
- Unpack the zip file.
- Double click the cf CLI executable.
- When prompted, click Install, then Close.

To verify your installation, open a terminal window and type cf. If your installation was successful, the cf CLI help listing appears.


CLI Command reference:
--------------------------

http://docs.cloudfoundry.org/cf-cli/cf-help.html

cf login, apps, env, marketplace, app <name>, services, create-service, bind-service, un-bind-service


