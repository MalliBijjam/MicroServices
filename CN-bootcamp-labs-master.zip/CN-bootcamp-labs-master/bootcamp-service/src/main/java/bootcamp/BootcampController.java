package bootcamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import hello.Greeting;

@RestController
public class BootcampController 
{
	@Autowired
    private Environment env;

	public static void main(String args[])
	{
			
	}
	
	@RequestMapping("/route")
	public Greeting route() {
		System.out.println("Enter route");
        RestTemplate restTemplate = new RestTemplate();
        
        //Task to do
        //Make use of rest template to route the request to the other service
        Greeting greeting = new Greeting();

        System.out.println(greeting);
        
        return greeting;
	}


}
