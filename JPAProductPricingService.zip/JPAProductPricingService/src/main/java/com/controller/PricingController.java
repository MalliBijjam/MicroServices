/**
 * 
 */
package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Pricing;
import com.service.PricingService;


/**
 * @author MA260329
 *
 */
@RestController
public class PricingController {

	@Autowired
	private PricingService pricingService;
	
	@RequestMapping(value= "/prices", method=RequestMethod.GET, produces="application/json")
	public ResponseEntity<List<Pricing>> getAllPricing()
	{
		return new ResponseEntity<List<Pricing>>(pricingService.getAllPricing(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value= "/prices/{id}", method=RequestMethod.GET, produces="application/json")
	public ResponseEntity<Pricing> getPricing(@PathVariable long id) {
		return new ResponseEntity<Pricing>(pricingService.getPricing(id), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/prices")
	public ResponseEntity<String> addPricing(@RequestBody Pricing pricing) {
		System.out.println("pricing object::"+pricing);
		return new ResponseEntity<String>(pricingService.addPricing(pricing), HttpStatus.OK);
	}

	@RequestMapping(method=RequestMethod.PUT, value="/prices/{id}")
	public ResponseEntity<String> updatePricing(@PathVariable long id, @RequestBody Pricing pricing)
	{
		return new ResponseEntity<String>(pricingService.updatePricing(id, pricing), HttpStatus.OK);
	}

	@RequestMapping(method=RequestMethod.DELETE, value="/prices/{id}")
	public ResponseEntity<String> deletePricing(@PathVariable long id)
	{
		Pricing pricing = new Pricing();
		pricing.setProductId(id);
		return new ResponseEntity<String>(pricingService.deletePricing(pricing), HttpStatus.OK);
	}

}
