/**
 * 
 */
package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Inventory;
import com.service.InventoryService;

/**
 * @author MA260329
 *
 */
@RestController
public class InventoryController {

	@Autowired
	private InventoryService inventoryService;
	
	@RequestMapping(value= "/inventories/{productId}", method=RequestMethod.GET, produces="application/json")
	public ResponseEntity<Inventory> getInventoryByProdID(@PathVariable long productId) {
		return new ResponseEntity<Inventory>(inventoryService.getInventoryByProdID(productId), HttpStatus.OK);
	}

	@RequestMapping(method=RequestMethod.POST,value="/inventories")
	public ResponseEntity<String> addInventory(@RequestBody Inventory inventory) {
		return new ResponseEntity<String>(inventoryService.addInventory(inventory), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/inventories/{productId}")
	public ResponseEntity<String> updateInventory(@PathVariable long productId, @RequestBody Inventory inventory) {
		return new ResponseEntity<String>(inventoryService.updateInventory(productId, inventory), HttpStatus.OK);
	}


}
