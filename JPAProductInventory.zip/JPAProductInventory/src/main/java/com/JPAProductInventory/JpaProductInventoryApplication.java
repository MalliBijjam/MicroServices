package com.JPAProductInventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaProductInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaProductInventoryApplication.class, args);
	}
}
