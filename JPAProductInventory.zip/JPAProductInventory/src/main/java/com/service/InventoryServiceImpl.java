/**
 * 
 */
package com.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.entity.Inventory;
import com.entity.ProductVO;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.repository.InventoryRepository;

/**
 * @author MA260329
 *
 */
@Service("InventoryService")
public class InventoryServiceImpl implements InventoryService {

	@Autowired
	InventoryRepository inventoryRepository;
	
	@Autowired
	private RestTemplateBuilder restTemplateBuilder;

	@Autowired
	private EurekaClient eurekaClient;
	
	RestTemplate restTemplate;
	
	@Override
	public Inventory getInventoryByProdID(long productId) {
		// TODO Auto-generated method stub
		return inventoryRepository.findOne(productId);
	}

	@Override
	public String addInventory(Inventory inventory) {
		// TODO Auto-generated method stub
		inventoryRepository.save(inventory);
		if(inventory != null) {
			ProductVO productVO = new ProductVO();
			productVO.setProductId(inventory.getProductId());
			productVO.setInventoryId(inventory.getInventoryId());
			productVO.setProductQuantity(inventory.getProductQuantity());
			productVO.setVendorId(inventory.getVendorId());
			productVO.setVendorName(inventory.getVendorName());
			productVO.setVendorLocation(inventory.getVendorLocation());

			
			System.out.println("productVO.getProductId():::"+productVO.getProductId());

			restTemplate = restTemplateBuilder.build();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			
			InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("product-view-service-app", false);
			String baseUrl = instanceInfo.getHomePageUrl();
			baseUrl = baseUrl +"inventoryToView";
			System.out.println("baseUrl:::::"+baseUrl);

			restTemplate.postForObject(baseUrl, productVO, ProductVO.class);

		}
		
		return "Inventory got added successfully";
	}

	@Override
	public String updateInventory(long productId, Inventory inventory) {
		// TODO Auto-generated method stub

		Inventory inv = inventoryRepository.findOne(productId);
	    if (inv.getProductId() == inventory.getProductId()) {
			System.out.println("inside if, product id matches to update inventory details");
			inv.setInventoryId(inventory.getInventoryId());
			inv.setProductId(inventory.getProductId());
			inv.setProductQuantity(inventory.getProductQuantity());
			inv.setVendorId(inventory.getVendorId());
			inv.setVendorName(inventory.getVendorName());
			inv.setVendorLocation(inventory.getVendorLocation());
			inventoryRepository.save(inv);
			
			//To update inventory details to Product View
				ProductVO productVO = new ProductVO();
				productVO.setProductId(inventory.getProductId());
				productVO.setInventoryId(inventory.getInventoryId());
				productVO.setProductQuantity(inventory.getProductQuantity());
				productVO.setVendorId(inventory.getVendorId());
				productVO.setVendorName(inventory.getVendorName());
				productVO.setVendorLocation(inventory.getVendorLocation());

				
				System.out.println("productVO.getProductId():::"+productVO.getProductId());

				restTemplate = restTemplateBuilder.build();
				restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
				restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
				
				Map<String, Long> uriVariables = new HashMap<String, Long>();
				uriVariables.put("id", productId);
				
				InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("product-view-service-app", false);
				String baseUrl = instanceInfo.getHomePageUrl();
				baseUrl = baseUrl +"inventoryToView/{id}";
				System.out.println("baseUrl:::::"+baseUrl);

				restTemplate.put(baseUrl, productVO, uriVariables);

			
			return "Inventory got updated Successfully";
		} else {
			System.out.println("inside else, product id not matches to update inventory details");
			return "Inventory got failed to updated due to mismatch of product id to update";
		}
	
	}

}
