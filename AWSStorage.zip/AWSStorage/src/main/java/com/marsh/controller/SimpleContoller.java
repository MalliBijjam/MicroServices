/**
 * 
 */
package com.marsh.controller;

import java.time.LocalTime;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author MA260329
 *
 */
@RestController
@RequestMapping("/")
@Component
public class SimpleContoller {
	@RequestMapping
	  public String handleRequest (Model model) {
	      model.addAttribute("message", "A message from the controller");
	      model.addAttribute("time", LocalTime.now());
	      return "home";
	  }
}
