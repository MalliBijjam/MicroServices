/**
 * 
 */
package com.marsh.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * @author MA260329
 *
 */
@Configuration
public class AmazonS3Config {

	@Value("{marsh.aws.access_key_id}")
	private String accessKeyId;
	
	@Value("{marsh.aws.secret_access_key}")
	private String secretAccessKey;
	
	@Value("{marsh.s3.region}")
	private String region;
	
	
}
