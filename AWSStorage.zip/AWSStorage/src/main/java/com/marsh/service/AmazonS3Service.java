/**
 * 
 */
package com.marsh.service;

import java.util.List;

/**
 * @author MA260329
 *
 */
public interface AmazonS3Service {

	public List<String> listFiles();
}
