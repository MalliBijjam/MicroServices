/**
 * 
 */
package com.marsh.service;

import java.util.List;

/**
 * @author MA260329
 *
 */
public class AmazonS3ServiceImpl implements AmazonS3Service{

	@Override
	public List<String> listFiles() {
		// TODO Auto-generated method stub
		return null;
	}

}
