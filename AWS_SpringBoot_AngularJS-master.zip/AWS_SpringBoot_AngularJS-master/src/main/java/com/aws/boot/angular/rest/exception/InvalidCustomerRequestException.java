package com.aws.boot.angular.rest.exception;

/**
* @author Krishna Bhat
*
*/

public class InvalidCustomerRequestException extends RuntimeException {
	private static final long serialVersionUID = 2468434988680850339L;
}
