# AWS_SpringBoot_AngularJS
Java application to the AWS cloud platform (EC2, Relational Database Service, S3 Storage) and front end AngularJS. Very simple customer management app (CRUD).


# Running APIs via Swagger API
After running your springboot application, enter this URL to your bworser
http://localhost:8080/swagger-ui.html

# To check your AWS RDS;
First create the new RDS instance on AWS acccount and create username and password as Security group.<br />
Then set environment variables for AWS key and secret either from device or from STS run->configuration->environment tab
Run application and can test your rest APIs.

You can find few simple AWS examples from this link: https://github.com/krishnabhat81/aws-examples 
