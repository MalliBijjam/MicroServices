/**
 * 
 */
package com.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author MA260329
 *
 */
@Entity
@Table(name="JPA_Promotion")
public class Promotion implements Serializable{
	
	@Id
	long productId;

	String promotionId;
	
	String promotionType;
	
	double promotionValue;
	
	/**
	 * @param productId
	 * @param promotionId
	 * @param promotionType
	 * @param promotionValue
	 */
	public Promotion(long productId, String promotionId, String promotionType, double promotionValue) {
		super();
		this.productId = productId;
		this.promotionId = promotionId;
		this.promotionType = promotionType;
		this.promotionValue = promotionValue;
	}



	/**
	 * @return the promotionValue
	 */
	public double getPromotionValue() {
		return promotionValue;
	}



	/**
	 * @param promotionValue the promotionValue to set
	 */
	public void setPromotionValue(double promotionValue) {
		this.promotionValue = promotionValue;
	}



	/**
	 * 
	 */
	public Promotion() {
		super();
	}



	/**
	 * @return the productId
	 */
	public long getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(long productId) {
		this.productId = productId;
	}

	/**
	 * @return the promotionId
	 */
	public String getPromotionId() {
		return promotionId;
	}

	/**
	 * @param promotionId the promotionId to set
	 */
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}

	
	/**
	 * @return the promotionType
	 */
	public String getPromotionType() {
		return promotionType;
	}


	/**
	 * @param promotionType the promotionType to set
	 */
	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}


	
	
}
