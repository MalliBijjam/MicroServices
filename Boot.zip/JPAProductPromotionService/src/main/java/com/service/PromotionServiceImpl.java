package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.entity.ProductVO;
import com.entity.Promotion;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.repository.PromotionRepository;

/**
 * @author MA260329
 *
 */
@Service("PromotionService")
public class PromotionServiceImpl implements PromotionService{

	@Autowired
	PromotionRepository promotionRepository;
	
	@Autowired
	private RestTemplateBuilder restTemplateBuilder;

	@Autowired
	private EurekaClient eurekaClient;
	
	RestTemplate restTemplate;
	
	@Override
	public Promotion getPromotion(long productId) {
		// TODO Auto-generated method stub
		return promotionRepository.findOne(productId);
	}

	@Override
	public String addPromotion(Promotion promotion) {
		// TODO Auto-generated method stub
		promotionRepository.save(promotion);
		
		return "Promotion got added successfully";
	}

	@Override
	public String updatePromotion(long productId, Promotion promotion) {
		// TODO Auto-generated method stub
		Promotion promo = promotionRepository.findOne(productId);
		if (promo.getProductId() == promotion.getProductId()) {
			System.out.println("inside if, product id matches to update promotion details");
			promo.setProductId(promotion.getProductId());
			promo.setPromotionId(promotion.getPromotionId());
			promo.setPromotionType(promotion.getPromotionType());
			promo.setPromotionValue(promotion.getPromotionValue());
			promotionRepository.save(promo);
			return "Product Promotion update is done successfully";
		} else {
			System.out.println("inside else, product id not matches to update promotion details");
			return "Product Promotion update is NOT done successfully due to product id mismatch";
		}
	}

	@Override
	public String deletePromotion(Promotion promotion) {
		// TODO Auto-generated method stub
		promotionRepository.delete(promotion);
		return "Product promotion got deleted successfully";
	}

	@Override
	public List<Promotion> getAllPromotions() {
		// TODO Auto-generated method stub
		return promotionRepository.findAll();
	}

}
