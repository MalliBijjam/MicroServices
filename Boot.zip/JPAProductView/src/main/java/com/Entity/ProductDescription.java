/**
 * 
 */
package com.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author MA260329
 *
 */
@Embeddable
public class ProductDescription implements Serializable{

	@Column String productColor;
	@Column String productSize;
	@Column String productSpec;
	/**
	 * @return the productColor
	 */
	public String getProductColor() {
		return productColor;
	}
	/**
	 * @param productColor the productColor to set
	 */
	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}
	/**
	 * @return the productSize
	 */
	public String getProductSize() {
		return productSize;
	}
	/**
	 * @param productSize the productSize to set
	 */
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	/**
	 * @return the productSpec
	 */
	public String getProductSpec() {
		return productSpec;
	}
	/**
	 * @param productSpec the productSpec to set
	 */
	public void setProductSpec(String productSpec) {
		this.productSpec = productSpec;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProductDescription [productColor=" + productColor + ", productSize=" + productSize + ", productSpec="
				+ productSpec + "]";
	}
	/**
	 * @param productColor
	 * @param productSize
	 * @param productSpec
	 */
	public ProductDescription(String productColor, String productSize, String productSpec) {
		super();
		this.productColor = productColor;
		this.productSize = productSize;
		this.productSpec = productSpec;
	}
	/**
	 * 
	 */
	public ProductDescription() {
		super();
	}
	
}
