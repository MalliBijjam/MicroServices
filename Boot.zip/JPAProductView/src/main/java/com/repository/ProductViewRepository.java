/**
 * 
 */
package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Entity.ProductView;

/**
 * @author MA260329
 *
 */
@Repository("ProductViewRepository")
public interface ProductViewRepository extends JpaRepository<ProductView, Long> {

}
