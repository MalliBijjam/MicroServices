/**
 * 
 */
package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.ProductView;
import com.service.ProductViewService;

/**
 * @author MA260329
 *
 */
@RestController
public class ProductViewController {

	@Autowired
	ProductViewService productViewService;

	@RequestMapping(value = "/products", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<ProductView>> getAllProducts() {
		return new ResponseEntity<List<ProductView>>(productViewService.getAllProducts(), HttpStatus.OK);
	}

	@RequestMapping(value = "/products/{productId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<ProductView> getProduct(@PathVariable long productId) {
		return new ResponseEntity<ProductView>(productViewService.getProduct(productId), HttpStatus.OK);
	}

	@RequestMapping(value = "/productToView", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> addProduct(@RequestBody ProductView productview) {
		System.out.println("inside controller...save product method..." + productview.getProductId() + " "
				+ productview.getProductName());
		return new ResponseEntity<String>(productViewService.saveProductToView(productview), HttpStatus.OK);
	}

	@RequestMapping(value = "/productToView/{id}", method = RequestMethod.PUT)
	public ResponseEntity<String> updateProduct(@PathVariable long id, @RequestBody ProductView productView) {
		System.out.println("inside controller...update product method");
		return new ResponseEntity<String>(productViewService.updateProduct(id, productView), HttpStatus.OK);
	}

	@RequestMapping(value = "/inventoryToView", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<ProductView> saveProductInventory(@RequestBody ProductView productview) {
		System.out.println("inside controller...save product inventory method..." + productview.getProductId());
		return new ResponseEntity<ProductView>(productViewService.saveInventoryToView(productview), HttpStatus.OK);
	}

	@RequestMapping(value = "/inventoryToView/{id}", method = RequestMethod.PUT)
	@ResponseBody
	public ResponseEntity<String> updateProductInventory(@PathVariable long id, @RequestBody ProductView productview) {
		System.out.println("inside controller...update product inventory method..." + productview.getProductId());
		return new ResponseEntity<String>(productViewService.updateInventoryToView(id, productview), HttpStatus.OK);
	}

	@RequestMapping(value = "/pricingToView", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<ProductView> saveProductPricing(@RequestBody ProductView productview) {
		System.out.println("inside controller...save product pricing method..." + productview.getProductId());
		return new ResponseEntity<ProductView>(productViewService.savePricingToView(productview), HttpStatus.OK);
	}

	@RequestMapping(value = "/pricingToView/{id}", method = RequestMethod.PUT)
	@ResponseBody
	public ResponseEntity<String> updteProductPricing(@PathVariable long id,
			@RequestBody ProductView productview) {
		System.out.println("inside controller...save product pricing method..." + productview.getProductId());
		return new ResponseEntity<String>(productViewService.updateProductPricing(id, productview), HttpStatus.OK);
	}

}
