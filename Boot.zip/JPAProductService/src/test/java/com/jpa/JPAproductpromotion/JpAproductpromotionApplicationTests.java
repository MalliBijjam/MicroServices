package com.jpa.JPAproductpromotion;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.JPAProductServiceApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = JPAProductServiceApplication.class)
public class JpAproductpromotionApplicationTests {

	@Test
	public void contextLoads() {
	}

}
