/**
 * 
 */
package com.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author MA260329
 *
 */
@Embeddable
public class ProductDescription implements Serializable{

	@Column String productColor;
	@Column String productSize;
	@Column String productStatus;
	@Column String productSpecification;

	
	
	
	/**
	 * @return the productColor
	 */
	public String getProductColor() {
		return productColor;
	}
	/**
	 * @param productColor the productColor to set
	 */
	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}
	/**
	 * @return the productSize
	 */
	public String getProductSize() {
		return productSize;
	}
	/**
	 * @param productSize the productSize to set
	 */
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	
	/**
	 * 
	 */
	public ProductDescription() {
		super();
	}

	/**
	 * @return the productStatus
	 */
	public String getProductStatus() {
		return productStatus;
	}
	/**
	 * @param productStatus the productStatus to set
	 */
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}
	/**
	 * @return the productSpecification
	 */
	public String getProductSpecification() {
		return productSpecification;
	}
	/**
	 * @param productSpecification the productSpecification to set
	 */
	public void setProductSpecification(String productSpecification) {
		this.productSpecification = productSpecification;
	}
	/**
	 * @param productColor
	 * @param productSize
	 * @param productStatus
	 * @param productSpecification
	 */
	public ProductDescription(String productColor, String productSize, String productStatus,
			String productSpecification) {
		super();
		this.productColor = productColor;
		this.productSize = productSize;
		this.productStatus = productStatus;
		this.productSpecification = productSpecification;
	}
	
}
