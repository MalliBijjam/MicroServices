/**
 * 
 */
package com.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author MA260329
 *
 */

@Table(name="JPA_Product")
@Entity
public class Product implements Serializable{

//	@EmbeddedId

	@Id
	long productId;
	@Column String productName;
	@Column String productCategory;

	
//	@JsonIgnore
	@Embedded ProductDescription productDescription;
	
	
	//transient String Vendor;
	
	/**
	 * 
	 */
	public Product() {
		super();
	}



	/**
	 * @param productId
	 * @param productName
	 * @param productCategory
	 * @param productDescription
	 */
	public Product(long productId, String productName, String productCategory, ProductDescription productDescription) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
		this.productDescription = productDescription;
	}



	/**
	 * @return the productId
	 */
	public long getProductId() {
		return productId;
	}




	/**
	 * @param productId the productId to set
	 */
	public void setProductId(long productId) {
		this.productId = productId;
	}




	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}




	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}




	/**
	 * @return the productDescription
	 */
	public ProductDescription getProductDescription() {
		return productDescription;
	}


	/**
	 * @param productDescription the productDescription to set
	 */
	public void setProductDescription(ProductDescription productDescription) {
		this.productDescription = productDescription;
	}



	/**
	 * @return the productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}



	/**
	 * @param productCategory the productCategory to set
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
		
}
