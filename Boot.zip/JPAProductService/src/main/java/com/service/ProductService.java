/**
 * 
 */
package com.service;

import java.util.List;

import com.entity.Product;

/**
 * @author MA260329
 *
 */
public interface ProductService {

	public List<Product> getAllProducts();
	public Product getProductById(long id);
	List<Product>  getProductByName(String Name);
	
	public String saveProduct(Product product);
	//public String removeProduct(Product product);
	
	String updateProduct(long id, Product product);
}

