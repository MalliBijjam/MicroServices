/**
 * 
 */
package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.entity.Product;
import com.entity.ProductVO;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.repository.ProductRepository;

/**
 * @author MA260329
 *
 */
@Service("ProductService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepository;

	@Autowired
	private RestTemplateBuilder restTemplateBuilder;

	@Autowired
	private EurekaClient eurekaClient;

	RestTemplate restTemplate;

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(long id) {
		// TODO Auto-generated method stub
		return productRepository.findOne(id);
	}

	@Override
	public String saveProduct(Product product) {
		// TODO Auto-generated method stub
		Product existingProduct = productRepository.findOne(product.getProductId());
		Product savedProduct = null;
		if (existingProduct == null) {
			savedProduct = productRepository.save(product);
			System.out.println("new Product is saved::::" + savedProduct);
		} else {
			if (existingProduct.getProductId() != product.getProductId()) {
				savedProduct = productRepository.save(product);
				System.out.println("Anothe Product id saved successfully");
			} else {
				return "Product id is alraedy exists in database";
			}

		}

		if (savedProduct != null) {
			ProductVO productVO = new ProductVO();
			productVO.setProductId(product.getProductId());
			productVO.setProductName(product.getProductName());
			productVO.setProductCategory(product.getProductCategory());
			productVO.setProductColor(product.getProductDescription().getProductColor());
			productVO.setProductSize(product.getProductDescription().getProductSize());
			productVO.setProductStatus(product.getProductDescription().getProductStatus());
			productVO.setProductSpecification(product.getProductDescription().getProductSpecification());

			System.out.println("product.getProductId():::" + product.getProductId());
			System.out.println("product.getProductName():::" + product.getProductName());

			restTemplate = restTemplateBuilder.build();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());

			InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("product-view-service-app", false);
			String baseUrl = instanceInfo.getHomePageUrl();
			System.out.println("instanceInfo.getHomePageUrl():::::" + baseUrl);
			baseUrl = baseUrl + "productToView";

			restTemplate.postForObject(baseUrl, productVO, String.class);
		}
		return "Product got saved Successfully";
	}

	/*
	 * @Override public String removeProduct(Product product) { // TODO
	 * Auto-generated method stub productRepository.delete(product);
	 * 
	 * return "Product deleted Successfully"; }
	 */

	@Override
	public List<Product> getProductByName(String Name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateProduct(long id, Product product) {
		System.out.println("inside updateProduct method.....");
		// TODO Auto-generated method stub
		Product pro = productRepository.findOne(id);
		Product savedProduct;
		if (product.getProductId() == id) {
			System.out.println("If product id matches to update");
			pro.setProductId(product.getProductId());
			pro.setProductName(product.getProductName());
			pro.setProductCategory(product.getProductCategory());
			pro.setProductDescription(product.getProductDescription());
			savedProduct = productRepository.save(pro);

			if (savedProduct != null) {
				ProductVO productVO = new ProductVO();
				productVO.setProductId(product.getProductId());
				productVO.setProductName(product.getProductName());
				productVO.setProductCategory(product.getProductCategory());
				productVO.setProductColor(product.getProductDescription().getProductColor());
				productVO.setProductSize(product.getProductDescription().getProductSize());
				productVO.setProductStatus(product.getProductDescription().getProductStatus());
				productVO.setProductSpecification(product.getProductDescription().getProductSpecification());

				restTemplate = restTemplateBuilder.build();
				restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
				restTemplate.getMessageConverters().add(new StringHttpMessageConverter());

				InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("product-view-service-app", false);
				String baseUrl = instanceInfo.getHomePageUrl();
				baseUrl = baseUrl + "productToView/{id}";
				System.out.println("instanceInfo.getHomePageUrl():::::" + baseUrl);
				Map<String, Long> uriVariables = new HashMap<String, Long>();
				uriVariables.put("id", id);

				restTemplate.put(baseUrl, productVO, uriVariables);

				/*
				 * restTemplate = restTemplateBuilder.build();
				 * restTemplate.getMessageConverters().add(new
				 * MappingJackson2HttpMessageConverter());
				 * restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
				 * 
				 * //Map<String, Long> uriVariables = new HashMap(); Map<String, Long>
				 * uriVariables = new HashMap<String, Long>();
				 * 
				 * 
				 * InstanceInfo instanceInfo =
				 * eurekaClient.getNextServerFromEureka("product-view-service-app", false);
				 * String baseUrl = instanceInfo.getHomePageUrl();
				 */
				// System.out.println("instanceInfo.getHomePageUrl():::::"+baseUrl);
				// baseUrl = baseUrl +"updateProductsView"+"/"+id+"";
				// baseUrl = baseUrl +"updateProductsView/";//+"{"+"id"+"}";

				/*
				 * uriVariables.put("id", id);
				 * 
				 * 
				 * System.out.println("baseUrl:::::"+baseUrl);
				 * System.out.println("uriVariables:::"+uriVariables +
				 * " "+uriVariables.toString() + " "+ uriVariables.get("id"));
				 * 
				 * ProductVO response = restTemplate.patchForObject(baseUrl, productVO,
				 * ProductVO.class, uriVariables);
				 * System.out.println("response::::"+response.toString());
				 */
			}

			return "Product has been updated successfully";
		} else {
			System.out.println("Else part where product id does not match to update");
			return "Product has NOT been updated successfully due to product id mismatch";
		}

		/*
		 * for(int i=0;i<getAllProducts().size();i++) { Product
		 * prod=getAllProducts().get(i); if(prod.getId() == (id)) {
		 * getAllProducts().set(i, prod); return 2; } }
		 */
	}

}
