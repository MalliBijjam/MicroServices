/**
 * 
 */
package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Product;
import com.service.ProductService;

/**
 * @author MA260329
 *
 */
@RestController
public class ProductController {

	@Autowired
	ProductService productService;
	

	/*@RequestMapping("/products")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}*/
	
	@RequestMapping(value="/products", method=RequestMethod.GET, produces="application/json")
	public ResponseEntity<List<Product>> getAllProducts(){
		return new ResponseEntity<List<Product>>(productService.getAllProducts(), HttpStatus.OK);
	}
	
	/*@RequestMapping("/products/{id}")
	public Product getProduct(@PathVariable long id){
		return productService.getProductById(id);
	}*/
	
	@RequestMapping(value="/products/{id}", method=RequestMethod.GET, produces="application/json")
	public ResponseEntity<Product> getProduct(@PathVariable long id){
		return new ResponseEntity<Product>(productService.getProductById(id), HttpStatus.OK);
	}
	
	/*@RequestMapping(method=RequestMethod.POST, value = "/products")
		public void addProduct(@RequestBody Product product) {
		productService.saveProduct(product);
	}*/
	@RequestMapping(value="/products", method=RequestMethod.POST)
	public ResponseEntity<String> addProduct(@RequestBody Product product){	
		System.out.println("product.getProductName::::"+product.getProductName());
		return new ResponseEntity<String>(productService.saveProduct(product), HttpStatus.OK);
	}
	
	
	/*@RequestMapping(method=RequestMethod.PUT, value = "/products/{id}")
	public void updateProduct(@PathVariable long id, @RequestBody Product product) {
		productService.updateProduct(id, product);
	}*/
	
	@RequestMapping(value="/products/{id}", method=RequestMethod.PUT)
	public ResponseEntity<String> updateProduct(@PathVariable long id, @RequestBody Product product) {
		return new ResponseEntity<String>(productService.updateProduct(id, product), HttpStatus.OK);
	}
	
	/*@RequestMapping(method=RequestMethod.DELETE, value = "/products/{id}")
	public void deleteProduct(@PathVariable long id) {
	productService.removeProduct(id);
	}*/

	/*@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteProduct(@PathVariable("id") long id) {
			
		Product product =new Product();
		product.setProductId(id);		
		return new ResponseEntity<String>(productService.removeProduct(product), HttpStatus.OK);
	}*/
	
}
