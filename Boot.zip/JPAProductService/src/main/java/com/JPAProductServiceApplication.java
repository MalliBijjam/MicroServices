package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class JPAProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JPAProductServiceApplication.class, args);
	}

/*@Bean
public CommandLineRunner setup(ProductRepository productRepository) {
	System.out.println("jpa example#####");
	return (args) ->{
		productRepository.save(new Product("Cell Phone",new ProductDescription("blue", "4 inches", "product spec....")));
		productRepository.save(new Product("Cell Phone",new ProductDescription("red", "5 inches", "product spec....")));
		productRepository.save(new Product("Cell Phone",new ProductDescription("orange", "6 inches", "product spec....")));
	};
}*/
}