/**
 * 
 */
package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.entity.Pricing;
import com.entity.ProductVO;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.repository.PricingRepository;

/**
 * @author MA260329
 *
 */
@Service("PricingService")
public class PricingServiceImpl implements PricingService {

	@Autowired
	PricingRepository pricingRepository;
	
	@Autowired
	private RestTemplateBuilder restTemplateBuilder;

	@Autowired
	private EurekaClient eurekaClient;
	
	RestTemplate restTemplate;

	@Override
	public List<Pricing> getAllPricing() {
		// TODO Auto-generated method stub
		return pricingRepository.findAll();
	}

	@Override
	public Pricing getPricing(long productId) {
		// TODO Auto-generated method stub
		return pricingRepository.findOne(productId);
	}

	

	@Override
	public String updatePricing(long id, Pricing pricing) {
		// TODO Auto-generated method stub
		Pricing price = pricingRepository.findOne(id);
		if (price.getProductId() == id) {
			System.out.println("inside if, product id matches to update pricing details");
			//price.setProductId(pricing.getProductId());
			price.setOginalPrice(pricing.getOginalPrice());
			price.setPromotionId(pricing.getPromotionId());
			price.setPromotionFlag(pricing.isPromotionFlag());
			pricingRepository.save(price);
			
			restTemplate = restTemplateBuilder.build();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			//To update pricing details to Product View
			ProductVO productVO = new ProductVO();
			productVO.setProductId(pricing.getProductId());
			productVO.setOginalPrice(pricing.getOginalPrice());
			productVO.setPromotionId(pricing.getPromotionId());
			productVO.setPromotionFlag(pricing.isPromotionFlag());
			
			if(pricing.isPromotionFlag()) {
			
				InstanceInfo instanceInfo2 = eurekaClient.getNextServerFromEureka("product-promotion-service-app", false);
				String baseUrl2 = instanceInfo2.getHomePageUrl();
				baseUrl2 = baseUrl2 +"promotions";
				System.out.println("baseUrl2:::::"+baseUrl2);// + " rest"+ restTemplate.getForObject(baseUrl2, ProductVO.class));

				
				ProductVO[] productVOPromotion = restTemplate.getForObject(baseUrl2, ProductVO[].class);
				System.out.println("productVO.promotionType:::::"+productVOPromotion);
				
				for (ProductVO productVO2 : productVOPromotion) {
					String promoId = productVO2.getPromotionId();
					if(promoId.equals(pricing.getPromotionId())) {
						productVO.setPromotionType(productVO2.getPromotionType());
						productVO.setPromotionValue(productVO2.getPromotionValue());
					}
				}

			}

			Map<String, Long> uriVariables = new HashMap<String, Long>();
			uriVariables.put("id", id);
			InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("product-view-service-app", false);
			String baseUrl = instanceInfo.getHomePageUrl();
			baseUrl = baseUrl +"pricingToView/{id}";
			System.out.println("baseUrl:::::"+baseUrl);
			System.out.println("productVO.getpromovalue:::::"+productVO.getPromotionType());
			restTemplate.put(baseUrl, productVO, uriVariables);
			return "Product pricing has been updated successfully";

		}else {
			System.out.println("inside else, product id not matches to update pricing details");
			return "Product pricing has NOT been updated successfully due to mismatch in product id";
		}
	}

	@Override
	public String deletePricing(Pricing pricing) {
		// TODO Auto-generated method stub
		pricingRepository.delete(pricing);
		return "Product pricing got deleted successfully";
	}

	@SuppressWarnings("unchecked")
	@Override
	public String addPricing(Pricing pricing) {
		// TODO Auto-generated method stub
		pricingRepository.save(pricing);
		
		if(pricing != null) {
			ProductVO productVO = new ProductVO();
			productVO.setProductId(pricing.getProductId());
			productVO.setOginalPrice(pricing.getOginalPrice());
			productVO.setPromotionId(pricing.getPromotionId());
			productVO.setPromotionFlag(pricing.isPromotionFlag());

			
			System.out.println("productVO.getProductId():::"+productVO.getProductId());

			restTemplate = restTemplateBuilder.build();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			
			
			
			if(pricing.isPromotionFlag()) {
			
				System.out.println("productVO.getProductId():::"+productVO.getProductId());

				InstanceInfo instanceInfo2 = eurekaClient.getNextServerFromEureka("product-promotion-service-app", false);
				String baseUrl2 = instanceInfo2.getHomePageUrl();
				baseUrl2 = baseUrl2 +"promotions";
				System.out.println("baseUrl2:::::"+baseUrl2);// + " rest"+ restTemplate.getForObject(baseUrl2, ProductVO.class));

				
				
				ProductVO[] productVOPromotion = restTemplate.getForObject(baseUrl2, ProductVO[].class);
				System.out.println("productVO.promotionType:::::"+productVOPromotion.toString());
				
				for (ProductVO productVO2 : productVOPromotion) {
					String promoId = productVO2.getPromotionId();
					if(promoId.equals(pricing.getPromotionId())) {
						productVO.setPromotionType(productVO2.getPromotionType());
						productVO.setPromotionValue(productVO2.getPromotionValue());
					}
				}


			}

			InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("product-view-service-app", false);
			String baseUrl = instanceInfo.getHomePageUrl();
			baseUrl = baseUrl +"pricingToView";
			System.out.println("baseUrl:::::"+baseUrl);
			System.out.println("productVO.getpromovalue:::::"+productVO.getPromotionType());

			restTemplate.postForObject(baseUrl, productVO, ProductVO.class);
		}

		return "Product Pricing got saved successfully";
	}

}
