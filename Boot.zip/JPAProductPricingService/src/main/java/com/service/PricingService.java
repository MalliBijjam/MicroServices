/**
 * 
 */
package com.service;

import java.util.List;

import com.entity.Pricing;


/**
 * @author MA260329
 *
 */
public interface PricingService {

	public List<Pricing> getAllPricing();
	
	public Pricing getPricing(long id);
	
	public String addPricing(Pricing pricing);
	
	public String updatePricing(long id, Pricing pricing);
	
	public String deletePricing(Pricing pricing);
}
