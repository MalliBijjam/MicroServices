/**
 * 
 */
package com.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author MA260329
 *
 */
@Entity
@Table (name="JPA_Pricing")
public class Pricing implements Serializable{

	//@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	@Column long productId;
	@Column double oginalPrice;
	@Column String promotionId;
	@Column boolean promotionFlag;
	
	
	
	/**
	 * 
	 */
	public Pricing() {
		super();
	}
	/**
	 * @param productId
	 * @param oginalPrice
	 * @param promotionId
	 * @param promotionFlag
	 */
	public Pricing(long productId, double oginalPrice, String promotionId, boolean promotionFlag) {
		super();
		this.productId = productId;
		this.oginalPrice = oginalPrice;
		this.promotionId = promotionId;
		this.promotionFlag = promotionFlag;
	}
	/**
	 * @return the productId
	 */
	public long getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(long productId) {
		this.productId = productId;
	}
	/**
	 * @return the oginalPrice
	 */
	public double getOginalPrice() {
		return oginalPrice;
	}
	/**
	 * @param oginalPrice the oginalPrice to set
	 */
	public void setOginalPrice(double oginalPrice) {
		this.oginalPrice = oginalPrice;
	}
	/**
	 * @return the promotionId
	 */
	public String getPromotionId() {
		return promotionId;
	}
	/**
	 * @param promotionId the promotionId to set
	 */
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	/**
	 * @return the promotionFlag
	 */
	public boolean isPromotionFlag() {
		return promotionFlag;
	}
	/**
	 * @param promotionFlag the promotionFlag to set
	 */
	public void setPromotionFlag(boolean promotionFlag) {
		this.promotionFlag = promotionFlag;
	}
	
	
}
