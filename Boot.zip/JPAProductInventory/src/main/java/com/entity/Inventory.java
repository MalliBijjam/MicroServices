/**
 * 
 */
package com.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author MA260329
 *
 */

@Entity
@Table(name="JPA_Inventory")
public class Inventory implements Serializable {

	String inventoryId;
	@Id
	long productId;
	int productQuantity;
	String vendorId;
	String vendorName;
	String vendorLocation;

	
	


	/**
	 * @param inventoryId
	 * @param productId
	 * @param productQuantity
	 * @param vendorId
	 * @param vendorName
	 * @param vendorLocation
	 */
	public Inventory(String inventoryId, long productId, int productQuantity, String vendorId, String vendorName,
			String vendorLocation) {
		super();
		this.inventoryId = inventoryId;
		this.productId = productId;
		this.productQuantity = productQuantity;
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.vendorLocation = vendorLocation;
	}



	/**
	 * @return the inventoryId
	 */
	public String getInventoryId() {
		return inventoryId;
	}



	/**
	 * @param inventoryId the inventoryId to set
	 */
	public void setInventoryId(String inventoryId) {
		this.inventoryId = inventoryId;
	}



	/**
	 * @return the productId
	 */
	public long getProductId() {
		return productId;
	}



	/**
	 * @param productId the productId to set
	 */
	public void setProductId(long productId) {
		this.productId = productId;
	}



	/**
	 * @return the productQuantity
	 */
	public int getProductQuantity() {
		return productQuantity;
	}



	/**
	 * @param productQuantity the productQuantity to set
	 */
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}



	/**
	 * @return the vendorId
	 */
	public String getVendorId() {
		return vendorId;
	}



	/**
	 * @param vendorId the vendorId to set
	 */
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}



	/**
	 * 
	 */
	public Inventory() {
		super();
	}



	/**
	 * @return the vendorName
	 */
	public String getVendorName() {
		return vendorName;
	}



	/**
	 * @param vendorName the vendorName to set
	 */
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}



	/**
	 * @return the vendorLocation
	 */
	public String getVendorLocation() {
		return vendorLocation;
	}



	/**
	 * @param vendorLocation the vendorLocation to set
	 */
	public void setVendorLocation(String vendorLocation) {
		this.vendorLocation = vendorLocation;
	}
		
}
