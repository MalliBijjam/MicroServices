/**
 * 
 */
package com.service;

import com.entity.Inventory;

/**
 * @author MA260329
 *
 */
public interface InventoryService {

	public Inventory getInventoryByProdID(long productId);
	public String addInventory(Inventory inventory);
	public String updateInventory(long productId, Inventory inventory);
}
