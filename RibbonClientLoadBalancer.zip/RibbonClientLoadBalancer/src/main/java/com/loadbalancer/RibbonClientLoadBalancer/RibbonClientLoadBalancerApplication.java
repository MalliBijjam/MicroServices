package com.loadbalancer.RibbonClientLoadBalancer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class RibbonClientLoadBalancerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RibbonClientLoadBalancerApplication.class, args);
	}
	@Autowired
	RestTemplate restTemplate;
	
	@Bean
	@LoadBalanced //This helps in load balancing rest apis
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@RequestMapping("/whatsup")
	public String h1(@RequestParam(value="activity", defaultValue="Learning") String activity) {
		String subject = this.restTemplate.getForObject("http://serviceapp/message", String.class);
		
		return String.format("%s %s", activity, subject);
	}
}
