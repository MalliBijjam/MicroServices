package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Product;
import com.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService service;

	@RequestMapping(value="/product", method=RequestMethod.GET,produces = "application/json")
	@ResponseBody
	public ResponseEntity<List<Product>> getAllProducts(){	
		return new ResponseEntity<List<Product>>(service.getAllProducts(), HttpStatus.OK);
	}
	
	@RequestMapping(value="/product/{name}", method=RequestMethod.GET)
	public ResponseEntity<List<Product>> getProductsByName(@PathVariable("name") String name){	
		return new ResponseEntity<List<Product>>(service.getProductbyName(name), HttpStatus.OK);
	}
	
	@RequestMapping(value="/product", method=RequestMethod.POST)
	public ResponseEntity<String> addProduct(@RequestBody Product product){	
		System.out.println("#### "+product);
		return new ResponseEntity<String>(service.saveProduct(product), HttpStatus.OK);
	}


	@RequestMapping(value = "/product/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> removeToDoById(@PathVariable("id") int id) {
			
		Product product =new Product();
		product.setId(id);		
		service.removeProduct(product);
		return new ResponseEntity<String>("product has been deleted", HttpStatus.OK);
	}
	
}
