package com;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.dao.ProductRepository;
import com.entity.Product;
import com.entity.ProductDescription;

@SpringBootApplication
public class BuildApp {

	public static void main(String[] args) {
		SpringApplication.run(BuildApp.class,args);

	}
	
	@Bean
	public CommandLineRunner setup(ProductRepository repo){
		return (args)->{
			repo.save(new Product("Cell Phone",new ProductDescription("6 inches","Gold","Smart")));
			repo.save(new Product("Cell Phone",new ProductDescription("4 inches","Black","Regular")));
			repo.save(new Product("Cell Phone",new ProductDescription("5 inches","Silver","Smart")));
			
		};
	}

}
