package com.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MSC_Product")
public class Product implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	long id;	
	
	@Column String name;	
	
	@Embedded ProductDescription productDescription;
	
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ProductDescription getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(ProductDescription productDescription) {
		this.productDescription = productDescription;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", productDescription=" + productDescription + "]";
	}
	public Product(long id, String name, ProductDescription productDescription) {
		super();
		this.id = id;
		this.name = name;
		this.productDescription = productDescription;
	}
	public Product(String name, ProductDescription productDescription) {
		super();
		this.name = name;
		this.productDescription = productDescription;
	}
	
	public Product(){
		
	}

}
