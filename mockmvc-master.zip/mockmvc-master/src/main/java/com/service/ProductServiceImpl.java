package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProductRepository;
import com.entity.Product;

@Service("ProductService")
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository repo;

	@Override
	public List<Product> getAllProducts() {

		return repo.findAll();
	}

	@Override
	public Product getProductById(int id) {
		
		return repo.findOne((long)id);
	}

	@Override
	public List<Product> getProductbyName(String name) {
		
		return repo.findByName(name);
	}

	@Override
	public String saveProduct(Product product) {
		repo.save(product);
		
		return "SUCCESS";
	}

	@Override
	public void removeProduct(Product product) {
		repo.delete(product);
		
	}

	@Override
	public int updateProductName(int id, String name) {
		
		return repo.updateName(id, name);
	}

}
