package com.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.MockitoAnnotations.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dao.ProductRepository;

import com.entity.Product;
import com.entity.ProductDescription;

@RunWith(SpringJUnit4ClassRunner.class)
public class ProductServiceImlTest {

	@Mock
	private ProductRepository repo;

	@InjectMocks
	private ProductServiceImpl service;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllProducts() {
		Product p1 = new Product("name1", new ProductDescription("King", "Black", "Smart"));
		Product p2 = new Product("name2", new ProductDescription("Small", "Gold", "Regular"));
		Product p3 = new Product("name1", new ProductDescription("Medium", "Silver", "Smart"));
		List<Product> productsTest = new ArrayList<Product>();
		productsTest.add(p1);
		productsTest.add(p2);
		productsTest.add(p3);
		when(repo.findAll()).thenReturn(productsTest);
		
		List<Product> result = service.getAllProducts();
		assertNotNull(result);
		assertEquals(3, result.size());
	}
	
	@Test
	public void testGetAllProducts2() {
		Product p1 = new Product("name1", new ProductDescription("King", "Black", "Smart"));
		Product p2 = new Product("name2", new ProductDescription("Small", "Gold", "Regular"));
		Product p3 = new Product("name1", new ProductDescription("Medium", "Silver", "Smart"));
		List<Product> productsTest = new ArrayList<Product>();
		productsTest.add(p1);
		productsTest.add(p2);
		productsTest.add(p3);
		when(repo.findAll()).thenReturn(null);
		
		List<Product> result = service.getAllProducts();
		assertNull(result);
		assertEquals(3, result.size());
	}

	@Test
	public void testGetProductbyName1() {
		Product p1 = new Product(1, "name1", new ProductDescription("King", "Black", "Smart"));
		Product p2 = new Product(2, "name2", new ProductDescription("Small", "gold", "Regular"));
		Product p3 = new Product(3, "name1", new ProductDescription("Medium", "Silver", "Smart"));
		List<Product> productsTest = new ArrayList<Product>();
		productsTest.add(p1);
		productsTest.add(p3);

		when(repo.findByName("name1")).thenReturn(productsTest);
		List<Product> result = service.getProductbyName("name1");
		;
		assertNotNull(result);
		assertEquals(2, result.size());
	}

	@Test
	public void testGetProductbyName2() {
		Product p1 = new Product(1, "name1", new ProductDescription("King", "Black", "Smart"));
		Product p2 = new Product(2, "name2", new ProductDescription("Small", "gold", "Regular"));
		Product p3 = new Product(3, "name1", new ProductDescription("Medium", "Silver", "Smart"));
		List<Product> productsTest = new ArrayList<Product>();
		productsTest.add(p1);
		productsTest.add(p3);

		when(repo.findByName("")).thenReturn(null);
		List<Product> result = service.getProductbyName("");
		;
		assertNull(result);
	}

	@Test
	public void testGetProductById() {
		Product p1 = new Product(1, "name1", new ProductDescription("King", "Black", "Smart"));
		when(repo.findOne(1l)).thenReturn(p1);
		Product result = service.getProductById(1);
		assertNotNull(result);
		assertEquals("King", result.getProductDescription().getProductSize());
	}

	
	
	@Test
	public void testSaveProduct() {
		Product p1 = new Product(18, "name1", new ProductDescription("King", "Black", "Smart"));
		when(repo.save(p1)).thenReturn(p1);
		String result = service.saveProduct(p1);
		assertEquals("SUCCESS", result);
	}

	
	
	
	
	@Test
	public void testRemoveProduct() {
		Product product = new Product(4, "wer", new ProductDescription("King", "Black", "Smart"));
		service.removeProduct(product);
		verify(repo, times(1)).delete(product);
	}

	@Test
	public void testUpdateProductName() {
		Product product = new Product(4, "wer", new ProductDescription("King", "Black", "Smart"));
		when(repo.updateName(4, "changed")).thenReturn(1);

		int result = service.updateProductName(4, "changed");
		assertEquals(1, result);
	}

}
