package com.service;

import java.util.List;

import com.Entity.ProductView;

public interface ProductViewService {

	List<ProductView> getAllProducts();
	ProductView getProduct(long id);
	String saveProductToView(ProductView productview);
	String updateProduct(long id, ProductView productView);
	ProductView updateProduct(ProductView productview);
	ProductView saveInventoryToView(ProductView productview);
	String updateInventoryToView(long id, ProductView productview);
	ProductView savePricingToView(ProductView productview);
	String updateProductPricing(long id, ProductView productview);
}
