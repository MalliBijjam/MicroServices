/**
 * 
 */
package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Entity.ProductView;
import com.repository.ProductViewRepository;

/**
 * @author MA260329
 *
 */
@Service("ProductViewService")
public class ProductViewServiceImpl implements ProductViewService {

	@Autowired
	ProductViewRepository productViewRepository;

	@Override
	public List<ProductView> getAllProducts() {
		// TODO Auto-generated method stub
		return productViewRepository.findAll();
	}

	@Override
	public ProductView getProduct(long id) {
		// TODO Auto-generated method stub
		return productViewRepository.findOne(id);
	}

	//@SuppressWarnings("null")
	@Override
	public String saveProductToView(ProductView productView) {
		// TODO Auto-generated method stub
		System.out.println("inside saveProdutToView method....." + productView.getProductId());
		ProductView savedProduct = productViewRepository.findOne(productView.getProductId());
		ProductView newSavedProduct = new ProductView();
		/*
		 * ProductView savedProduct = new ProductView();
		 * 
		 * savedProduct.setProductId(productView.getProductId());
		 * savedProduct.setProductName(productView.getProductName());
		 * savedProduct.setProductCategory(productView.getProductCategory());
		 * savedProduct.setProductColor(productView.getProductColor());
		 * savedProduct.setProductSize(productView.getProductSize());
		 * savedProduct.setProductStatus(productView.getProductStatus());
		 * savedProduct.setProductSpecification(productView.getProductSpecification());
		 * productViewRepository.save(savedProduct); return
		 * "New Product is successfully saved to VIEW";
		 */

		if (savedProduct != null) {

			if (productView.getProductId() != savedProduct.getProductId()) {
				savedProduct.setProductId(productView.getProductId());
				savedProduct.setProductName(productView.getProductName());
				savedProduct.setProductCategory(productView.getProductCategory());
				savedProduct.setProductColor(productView.getProductColor());
				savedProduct.setProductSize(productView.getProductSize());
				savedProduct.setProductStatus(productView.getProductStatus());
				savedProduct.setProductSpecification(productView.getProductSpecification());
				productViewRepository.save(savedProduct);
				System.out.println("Another Product is successfully saved to VIEW");
				return "Another Product is successfully saved to VIEW";
			} else {
				System.out.println("Same Product is already exists in VIEW");
				return "Same Product is already exists in VIEW";
			}
		} else {
			newSavedProduct.setProductId(productView.getProductId());
			newSavedProduct.setProductName(productView.getProductName());
			newSavedProduct.setProductCategory(productView.getProductCategory());
			newSavedProduct.setProductColor(productView.getProductColor());
			newSavedProduct.setProductSize(productView.getProductSize());
			newSavedProduct.setProductStatus(productView.getProductStatus());
			newSavedProduct.setProductSpecification(productView.getProductSpecification());
			productViewRepository.save(newSavedProduct);
			System.out.println("New Product is successfully saved to VIEW");
			return "New Product is successfully saved to VIEW";
		}

		// return "Product is added successfully to View";
	}

	@Override
	public String updateProduct(long id, ProductView productView) {
		// TODO Auto-generated method stub
		ProductView savedProduct = productViewRepository.findOne(id);
		if (savedProduct.getProductId() == id) {
			savedProduct.setProductName(productView.getProductName());
			savedProduct.setProductCategory(productView.getProductCategory());
			savedProduct.setProductColor(productView.getProductColor());
			savedProduct.setProductSize(productView.getProductSize());
			savedProduct.setProductStatus(productView.getProductStatus());
			savedProduct.setProductSpecification(productView.getProductSpecification());
			productViewRepository.save(savedProduct);
			return "Product is updated successfully in View";
		} else {
			return "Product is NOT updated successfully in View due to product id mismatch";
		}
		/*
		 * ProductView savedProduct; if (productView.getProductId() == id) {
		 * System.out.println("If product id matches to update");
		 * savedProduct.setProductName(productView.getProductName());
		 * savedProduct.setProductCategory(productView.getProductCategory());
		 * savedProduct.getProductSize(productView.);
		 * productViewRepository.save(savedProduct); }
		 */

	}

	@Override
	public ProductView updateProduct(ProductView productView) {
		// TODO Auto-generated method stub
		return productViewRepository.save(productView);
	}

	@Override
	public ProductView saveInventoryToView(ProductView productView) {
		System.out.println("inside saveInventoryToView method....." + productView.getProductId());

		ProductView savedProduct = productViewRepository.findOne(productView.getProductId());
		System.out.println("inside saveInventoryToView method 2....." + savedProduct.getProductId());

		if (productView.getProductId() == savedProduct.getProductId()) {

			// savedProduct.setProductId(productView.getProductId());
			savedProduct.setInventoryId(productView.getInventoryId());
			savedProduct.setProductQuantity(productView.getProductQuantity());
			savedProduct.setVendorId(productView.getVendorId());
			savedProduct.setVendorName(productView.getVendorName());
			savedProduct.setVendorLocation(productView.getVendorLocation());

		}
		return productViewRepository.save(savedProduct);

	}

	@Override
	public String updateInventoryToView(long id, ProductView productView) {
		// TODO Auto-generated method stub
		System.out.println("inside updateInventoryToView method....." + id);

		ProductView savedProduct = productViewRepository.getOne(id);
		if (savedProduct.getProductId() == id) {

			// savedProduct.setProductId(productView.getProductId());
			savedProduct.setInventoryId(productView.getInventoryId());
			savedProduct.setProductQuantity(productView.getProductQuantity());
			savedProduct.setVendorId(productView.getVendorId());
			savedProduct.setVendorName(productView.getVendorName());
			savedProduct.setVendorLocation(productView.getVendorLocation());
			productViewRepository.save(savedProduct);
			return "Iventory is successfully updated to View";
		} else {
			return "Iventory is NOT successfully updated to View";
		}

	}

	@Override
	public ProductView savePricingToView(ProductView productView) {
		// TODO Auto-generated method stub
		ProductView savedProduct = productViewRepository.findOne(productView.getProductId());
		System.out.println("inside savePrcicingToView method....." + savedProduct.getProductId());

		if (productView.getProductId() == savedProduct.getProductId()) {

			// savedProduct.setProductId(productView.getProductId());
			savedProduct.setPromotionFlag(productView.isPromotionFlag());
			savedProduct.setPromotionId(productView.getPromotionId());
			savedProduct.setOginalPrice(productView.getOginalPrice());

			if (productView.isPromotionFlag()) {
				savedProduct.setPromotionType(productView.getPromotionType());
				savedProduct.setPromotionValue(productView.getPromotionValue());
				double actualPrice = productView.getOginalPrice();
				double discountPercentage = (100 - productView.getPromotionValue());
				double discountPrice = (actualPrice * discountPercentage) / 100;
				savedProduct.setDiscountPrice(discountPrice);
			}

		}
		return productViewRepository.save(savedProduct);
	}

	@Override
	public String updateProductPricing(long id, ProductView productView) {
		// TODO Auto-generated method stub
		ProductView savedProduct = productViewRepository.findOne(id);
		System.out.println("inside updatePrcicingToView method....." + savedProduct.getProductId());

		if (savedProduct.getProductId() == id) {

			// savedProduct.setProductId(productView.getProductId());
			savedProduct.setPromotionFlag(productView.isPromotionFlag());
			savedProduct.setPromotionId(productView.getPromotionId());
			savedProduct.setOginalPrice(productView.getOginalPrice());

			if (productView.isPromotionFlag()) {
				savedProduct.setPromotionType(productView.getPromotionType());
				savedProduct.setPromotionValue(productView.getPromotionValue());
				double actualPrice = productView.getOginalPrice();
				double discountPercentage = (100 - productView.getPromotionValue());
				double discountPrice = (actualPrice * discountPercentage) / 100;
				savedProduct.setDiscountPrice(discountPrice);
			}
			productViewRepository.save(savedProduct);
			return "Pricing details are successfully updated to View";
		} else {
			return "Pricing details are NOT successfully updated to View";
		}
	}

}
