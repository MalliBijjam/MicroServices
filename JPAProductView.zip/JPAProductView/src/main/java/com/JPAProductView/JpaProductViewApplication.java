package com.JPAProductView;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaProductViewApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaProductViewApplication.class, args);
	}
}
