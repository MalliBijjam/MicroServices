/**
 * 
 */
package com.service;

import java.util.List;

import com.entity.Product;

/**
 * @author MA260329
 *
 */
public interface ProductService {
	
	List<Product> getAllProducts();

	Product getProductById(int id);

	List<Product> getProductbyName(String name);

	String saveProduct(Product product);

	void removeProduct(Product product);

	int updateProductName(int id, String name);
}
