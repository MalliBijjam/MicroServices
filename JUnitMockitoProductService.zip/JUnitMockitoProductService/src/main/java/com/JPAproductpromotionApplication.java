package com;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.entity.Product;
import com.entity.ProductDescription;
import com.repository.ProductRepository;

@SpringBootApplication
public class JPAproductpromotionApplication {

	public static void main(String[] args) {
		SpringApplication.run(JPAproductpromotionApplication.class, args);
	}

@Bean
public CommandLineRunner setup(ProductRepository productRepository) {
	System.out.println("jpa example#####");
	return (args) ->{
		productRepository.save(new Product("Cell Phone",new ProductDescription("blue", "4 inches", "product spec....")));
		productRepository.save(new Product("Cell Phone",new ProductDescription("red", "5 inches", "product spec....")));
		productRepository.save(new Product("Cell Phone",new ProductDescription("orange", "6 inches", "product spec....")));
	};
}
}