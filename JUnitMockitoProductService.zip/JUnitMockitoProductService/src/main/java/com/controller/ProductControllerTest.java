package com.controller;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import org.junit.runners.MethodSorters;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.JPAproductpromotionApplication;
import com.entity.Product;
import com.entity.ProductDescription;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JPAproductpromotionApplication.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProductControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();

	}

	@Test
	public void test1GetAllProducts1() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/product")
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$", hasSize(3)))
				.andDo(print());

	}

	@Test
	public void test1GetAllProducts2() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/product")
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.[0].name").value("Cell Phone"))
				.andExpect(jsonPath("$.[0].productDescription.productColor").value("Gold"))
				.andDo(print());
	}

	@Test
	public void test2AddProduct() throws Exception {
		Product p = new Product("fff", new ProductDescription("6 inches", "Gold", "Smart"));
		mockMvc.perform(MockMvcRequestBuilders.post("/product/")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(p)))
				.andExpect(jsonPath("$").exists())
				.andExpect(jsonPath("$").value("SUCCESS"))
				.andDo(print());

	}

	// @Test
	// public void test3GetProductsByName() {
	//
	// }
	//
	//
	// @Test
	// public void test4RemoveToDoById() {
	//
	// }

}
