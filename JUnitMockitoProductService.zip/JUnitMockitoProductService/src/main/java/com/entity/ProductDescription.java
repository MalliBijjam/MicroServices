/**
 * 
 */
package com.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author MA260329
 *
 */
@Embeddable
public class ProductDescription implements Serializable{

	@Column String productColor;
	@Column String productSize;
	@Column String productSpec;
	public String getProductColor() {
		return productColor;
	}
	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	public String getProductSpec() {
		return productSpec;
	}
	public void setProductSpec(String productSpec) {
		this.productSpec = productSpec;
	}
	@Override
	public String toString() {
		return "ProductDescription [productColor=" + productColor + ", productSize=" + productSize + ", productSpec="
				+ productSpec + "]";
	}
	public ProductDescription(String productSize,String productColor,  String productSpec) {
		super();
		this.productColor = productColor;
		this.productSize = productSize;
		this.productSpec = productSpec;
	}
	public ProductDescription(){
		
	}
	
}
