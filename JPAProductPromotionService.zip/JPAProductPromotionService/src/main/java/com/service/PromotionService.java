/**
 * 
 */
package com.service;

import java.util.List;

import com.entity.Promotion;

/**
 * @author MA260329
 *
 */
public interface PromotionService {

	public List<Promotion> getAllPromotions();
	public Promotion getPromotion(long productId);
	public String addPromotion(Promotion promotion);
	public String updatePromotion(long productId, Promotion promotion);
	public String deletePromotion(Promotion promotion);
}
