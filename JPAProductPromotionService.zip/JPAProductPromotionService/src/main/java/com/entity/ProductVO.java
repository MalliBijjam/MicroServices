/**
 * 
 */
package com.entity;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

/**
 * @author MA260329
 *
 */
//@JsonAutoDetect

@Component
public class ProductVO {

	long productId;
	String productName;
	String productCategory;
	String productColor;
	String productSize;
	String productStatus;
	String productSpecification;
	
	double oginalPrice;
	String promotionId;
	boolean promotionFlag;
	
	String promotionType;
	
	double promotionValue;
	
	double discountPrice;
	
	String inventoryId;
	int productQuantity;
	String vendorId;
	String vendorName;
	String vendorLocation;

	
	/**
	 * @return the productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}
	/**
	 * @param productCategory the productCategory to set
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	/**
	 * @return the promotionType
	 */
	public String getPromotionType() {
		return promotionType;
	}
	/**
	 * @param promotionType the promotionType to set
	 */
	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}
	
	/**
	 * @return the productId
	 */
	public long getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(long productId) {
		this.productId = productId;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return the productColor
	 */
	public String getProductColor() {
		return productColor;
	}
	/**
	 * @param productColor the productColor to set
	 */
	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}
	/**
	 * @return the productSize
	 */
	public String getProductSize() {
		return productSize;
	}
	/**
	 * @param productSize the productSize to set
	 */
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	
	/**
	 * @return the oginalPrice
	 */
	public double getOginalPrice() {
		return oginalPrice;
	}
	/**
	 * @param oginalPrice the oginalPrice to set
	 */
	public void setOginalPrice(double oginalPrice) {
		this.oginalPrice = oginalPrice;
	}
	/**
	 * @return the promotionId
	 */
	public String getPromotionId() {
		return promotionId;
	}
	/**
	 * @param promotionId the promotionId to set
	 */
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	/**
	 * @return the promotionFlag
	 */
	public boolean isPromotionFlag() {
		return promotionFlag;
	}
	/**
	 * @param promotionFlag the promotionFlag to set
	 */
	public void setPromotionFlag(boolean promotionFlag) {
		this.promotionFlag = promotionFlag;
	}
	
	
	/**
	 * @return the discountPrice
	 */
	public double getDiscountPrice() {
		
		return discountPrice;
	}
	/**
	 * @param discountPrice the discountPrice to set
	 */
	public void setDiscountPrice(double discountPrice) {
		this.discountPrice = discountPrice;
	}
	/**
	 * @return the inventoryId
	 */
	public String getInventoryId() {
		return inventoryId;
	}
	/**
	 * @param inventoryId the inventoryId to set
	 */
	public void setInventoryId(String inventoryId) {
		this.inventoryId = inventoryId;
	}
	/**
	 * @return the productQuantity
	 */
	public int getProductQuantity() {
		return productQuantity;
	}
	/**
	 * @param productQuantity the productQuantity to set
	 */
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	/**
	 * @return the vendorId
	 */
	public String getVendorId() {
		return vendorId;
	}
	/**
	 * @param vendorId the vendorId to set
	 */
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	
	
	/**
	 * 
	 */
	public ProductVO() {
		super();
	}
	
	/**
	 * @return the productStatus
	 */
	public String getProductStatus() {
		return productStatus;
	}
	/**
	 * @param productStatus the productStatus to set
	 */
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}
	/**
	 * @return the promotionValue
	 */
	public double getPromotionValue() {
		return promotionValue;
	}
	/**
	 * @param promotionValue the promotionValue to set
	 */
	public void setPromotionValue(double promotionValue) {
		this.promotionValue = promotionValue;
	}
	/**
	 * @return the productSpecification
	 */
	public String getProductSpecification() {
		return productSpecification;
	}
	/**
	 * @param productSpecification the productSpecification to set
	 */
	public void setProductSpecification(String productSpecification) {
		this.productSpecification = productSpecification;
	}
	/**
	 * @return the vendorName
	 */
	public String getVendorName() {
		return vendorName;
	}
	/**
	 * @param vendorName the vendorName to set
	 */
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	/**
	 * @return the vendorLocation
	 */
	public String getVendorLocation() {
		return vendorLocation;
	}
	/**
	 * @param vendorLocation the vendorLocation to set
	 */
	public void setVendorLocation(String vendorLocation) {
		this.vendorLocation = vendorLocation;
	}
	/**
	 * @param productId
	 * @param productName
	 * @param productCategory
	 * @param productColor
	 * @param productSize
	 * @param productStatus
	 * @param productSpecification
	 * @param oginalPrice
	 * @param promotionId
	 * @param promotionFlag
	 * @param promotionType
	 * @param promotionValue
	 * @param discountPrice
	 * @param inventoryId
	 * @param productQuantity
	 * @param vendorId
	 * @param vendorName
	 * @param vendorLocation
	 */
	public ProductVO(long productId, String productName, String productCategory, String productColor,
			String productSize, String productStatus, String productSpecification, double oginalPrice,
			String promotionId, boolean promotionFlag, String promotionType, double promotionValue,
			double discountPrice, String inventoryId, int productQuantity, String vendorId, String vendorName,
			String vendorLocation) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
		this.productColor = productColor;
		this.productSize = productSize;
		this.productStatus = productStatus;
		this.productSpecification = productSpecification;
		this.oginalPrice = oginalPrice;
		this.promotionId = promotionId;
		this.promotionFlag = promotionFlag;
		this.promotionType = promotionType;
		this.promotionValue = promotionValue;
		this.discountPrice = discountPrice;
		this.inventoryId = inventoryId;
		this.productQuantity = productQuantity;
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.vendorLocation = vendorLocation;
	}
	
	
	
}
