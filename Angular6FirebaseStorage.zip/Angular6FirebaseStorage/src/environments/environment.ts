export const environment = {
  production: false,
  firebase: {
    apiKey: 'xxx',
    authDomain: 'jsa-angular6.firebaseapp.com',
    databaseURL: 'https://jsa-angular6.firebaseio.com',
    projectId: 'jsa-angular6',
    storageBucket: 'jsa-angular6.appspot.com',
    messagingSenderId: 'xxx'
  }
};
