package com.config.SpringConfigClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SpringConfigClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringConfigClientApplication.class, args);
	}
}

@RefreshScope 
@RestController
class MessageRestController{
	@Value("${message:Hello Default message}")
	private String message;
	
	@RequestMapping("/message")
	public String getMessage() {
		return this.message;
	}
	
	@Value("${user.role: Default role}")
	private String role;
	
	@RequestMapping(value="/whoami/{user.name",
			method = RequestMethod.GET,
			produces = MediaType.TEXT_PLAIN_VALUE
	)
	public String whoami(@PathVariable("username") String username) {
		return "Hello! You are "+username + ", you are a "+ role;
	}
}