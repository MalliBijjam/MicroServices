package com.product.view.productViewClientApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

@SpringBootApplication
public class ProductViewClientAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductViewClientAppApplication.class, args);
	}
}

@RestController
class ClientController{
	@Autowired
	private EurekaClient eurekaClient;
	@Autowired
	private RestTemplateBuilder restTemplateBuilder;
	
	@RequestMapping("/")
	public String invokeService() {
		RestTemplate restTemplate = restTemplateBuilder.build();
		
		

		
		InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("product-view-api-gateway", false);
		String baseUrl = instanceInfo.getHomePageUrl();
		baseUrl = baseUrl + "/api/product-service-app/fetchProduct";
		//http://localhost:6781/api/serviceapp/greet
		return restTemplate.getForObject(baseUrl, String.class);
	}
}
