/**
 * 
 */
package com;

/**
 * @author MA260329
 *
 */
public class MyDemo {

	public long add(int a, int b) {
		return a+b;
	}
	
	public String getName(String firstName, String lastName) {
		return firstName+lastName;
	}
}
