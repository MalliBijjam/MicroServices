/**
 * 
 */
package com;

/**
 * @author MA260329
 *
 */
public class MyMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
    System.out.println(new MyDemo().add(2, 3));
    System.out.println(new MyDemo().add(5, 8));

	}

}
