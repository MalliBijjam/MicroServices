/**
 * 
 */
package com;

import static org.junit.Assert.assertEquals;

/**
 * @author MA260329
 *
 */
public class DemoTest {

	public void testAdd() {
	//	assertEquals(new MyDemo().add(3,4));
	}
	
}
